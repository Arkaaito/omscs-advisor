from .menu import Menu, MenuItem

__version__ = '1.1.0'
__url__ = 'https://github.com/borgstrom/django-simple-menu'
